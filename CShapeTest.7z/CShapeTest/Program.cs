﻿using System;
using System.IO;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Text;

namespace MyApplication
{
    class XMLToObject
    {
        public static void Main()
        {
            // int init_i;
            // for (init_i = 0; init_i <= 8; init_i += 1) {
            //     System.Console.WriteLine(IntToString(init_i));
            // }
            // System.Console.WriteLine(IntToString(init_i));

            //TransXMLToDoodad();
            //TransXMLToUnit();
            //CodeInsert();
            //TransXMLCMDButton();

            //Print_MyIdea5();
            Console.WriteLine(StringToHexString("动图测试"));
        }

        /// <summary>
        /// 将字符串转换为十六进制字符串表示
        /// </summary>
        /// <param name="input">要转换的字符串</param>
        /// <returns>字符串的十六进制表示</returns>
        static string StringToHexString(string input)
        {
            // 将字符串转换为UTF-8字节数组
            byte[] bytes = Encoding.UTF8.GetBytes(input);

            // 创建一个StringBuilder来存储十六进制字符串
            StringBuilder hex = new StringBuilder(bytes.Length * 2);

            // 遍历字节数组，将每个字节转换为十六进制并添加到StringBuilder中
            foreach (byte b in bytes)
            {
                //hex.AppendFormat("{0:x2}", b);
                hex.AppendFormat("{0:X2}", b); //大写
            }

            // 返回十六进制字符串
            return hex.ToString();
        }

        /// <summary>
        /// 将中文转换为类似的十六进制表示
        /// </summary>
        static void Print_MyIdea7()
        {
            string chineseString = "镇";
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(chineseString);
            string hexString = "";
            foreach (byte b in bytes)
            {
                hexString += b.ToString("X3");
            }
            Console.WriteLine(hexString);
        }
        /// <summary>
        /// 将中文转换为类似的十六进制表示
        /// </summary>
        static void Print_MyIdea6()
        {
            string chineseString = "镇";
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(chineseString);
            string hexString = "";
            foreach (byte b in bytes)
            {
                hexString += b.ToString("X2");
            }
            Console.WriteLine(hexString);
        }

        /// <summary>
        /// Galaxy自动中文
        /// </summary>
        static void Print_MyIdea5()
        {
            string hexString = "E58AA8E59BBEE6B58BE8AF95";
            byte[] bytes = new byte[hexString.Length / 2];
            for (int i = 0; i < hexString.Length; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hexString.Substring(i, 2), 16);
            }
            string result = System.Text.Encoding.UTF8.GetString(bytes);
            Console.WriteLine(result);
        }

        static void Print_MyIdea4()
        {
            string s = "";
            string newLine = "";
            string a = "";
            int num = 2;
            string index = "17";
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 100)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectIcons\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", CatalogReferenceGet(\"Actor,Ravasaur,UnitIcon\", c_playerAny));"
                    + "\n";
                newLine += s;
            }
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 100)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectName\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", \"<s val=\\\"ys_BlueGreen204\\\">其他</s> -> \"+TextToString(UnitTypeGetName(\""
                    + "Barracks"
                    + "\""
                    + "))); "
                    + "\n";
                newLine += s;
            }
            Console.WriteLine(newLine);
        }

        static void Print_MyIdea3()
        {
            string s = "";
            string newLine = "";
            string a = "";
            int num = 40;
            string index = "14";
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 100)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectIcons\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", CatalogReferenceGet(\"Actor,Ravasaur,UnitIcon\", c_playerAny));"
                    + "\n";
                newLine += s;
            }
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 100)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectName\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", \"<s val=\\\"ys_BlueGreen204\\\">墙体</s> -> \"+\""
                    + "防御墙"
                    + a
                    + "\""
                    + ");"
                    + "\n";
                newLine += s;
            }
            Console.WriteLine(newLine);
        }

        static void Print_MyIdea2()
        {
            string s = "";
            string newLine = "";
            string a = "";
            int num = 3;
            string index = "12";
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 100)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectIcons\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", CatalogReferenceGet(\"Actor,Ravasaur,UnitIcon\", c_playerAny));"
                    + "\n";
                newLine += s;
            }
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 100)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectName\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", \"<s val=\\\"ys_BlueGreen204\\\">人类建造</s> -> \"+TextToString(UnitTypeGetName(gv_Ut_HBF"
                    + a
                    + ")));"
                    + "\n";
                newLine += s;
            }
            Console.WriteLine(newLine);
        }

        static void Print_MyIdea()
        {
            string s = "";
            string newLine = "";
            string a = "";
            int num = 12;
            string index = "13";
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "00" + i.ToString();
                }
                else if (i < 100)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 1000)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectIcons\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", CatalogReferenceGet(\"Actor,Ravasaur,UnitIcon\", c_playerAny));"
                    + "\n";
                newLine += s;
            }
            for (int i = 1; i <= num; i++)
            {
                if (i < 10)
                {
                    a = "00" + i.ToString();
                }
                else if (i < 100)
                {
                    a = "0" + i.ToString();
                }
                else if (i < 1000)
                {
                    a = i.ToString();
                }
                s =
                    "lib09CC5CC7_gf_SaveString2(true, \"ModEditOP_ObjectName\", "
                    + index
                    + ", "
                    + i.ToString()
                    + ", \"<s val=\\\"ys_BlueGreen204\\\">新人类建造</s> -> \"+TextToString(UnitTypeGetName(Ut_HB"
                    + a
                    + ")));"
                    + "\n";
                newLine += s;
            }
            Console.WriteLine(newLine);
        }

        static void Print_CRequirementAnd()
        {
            string s = "";
            string newLine = "";
            int a = 10001;
            for (int i = 0; i < 110; i++)
            {
                // string xml = "<LayoutButtons Face=\"AN10002\" Type=\"AbilCmd\" AbilCmd=\"MM_DaJian1,Research1\" Row=\"0\" Column=\"1\"/>";
                // s = "<s val=" + "\"" + "ys_yellow165" + "\\" + "\"" + ">单位生成：" + (i + 1).ToString() + "/285</s>";
                s =
                    "    <CRequirementAnd id="
                    + "\""
                    + "AndCountUpgradeSJ"
                    + (a + i).ToString()
                    + "CompleteOnlyCountUpgradeCCData_MoreVehiclesCompleteOnly"
                    + "\""
                    + ">"
                    + "\n"
                    + "        <Tooltip value="
                    + "\""
                    + "RequirementNode/Tooltip/##id##"
                    + "\""
                    + "/>"
                    + "\n"
                    + "        <OperandArray value="
                    + "\""
                    + "CountUpgradeSJ"
                    + (a + i).ToString()
                    + "CompleteOnly"
                    + "\""
                    + "/>"
                    + "\n"
                    + "        <OperandArray value="
                    + "\""
                    + "CountUpgradeCCData_MoreVehiclesCompleteOnly"
                    + "\""
                    + "/>"
                    + "\n"
                    + "    </CRequirementAnd>";
                newLine += s;
            }
            Console.WriteLine(newLine);
        }

        static void TransXMLCMDButton()
        {
            // 定义文件路径（确保路径是正确的）
            string filePath = "C:\\Users\\linsh\\Desktop\\cc.xml";
            try
            {
                // 加载XML文件
                XDocument doc = XDocument.Load(filePath);

                // 遍历所有的ObjectUnit元素
                foreach (var obj in doc.Descendants("LayoutButtons"))
                {
                    string face = obj.Attribute("Face").Value;
                    //正则匹配数字部分并加上14
                    face = IncrementFaceNumber(face);

                    // 设置更新后的Face值
                    obj.Attribute("Face").Value = face;

                    // 控制台输出修改后的整个obj元素
                    Console.WriteLine("            " + obj);
                }
            }
            catch (IOException ex)
            {
                // 处理文件读取过程中的异常
                Console.WriteLine("Error reading the file: " + ex.Message);
            }
        }

        public static string IncrementFaceNumber(string face)
        {
            // 使用正则表达式匹配数字部分
            Match match = Regex.Match(face, @"\d+");

            // 检查是否找到了匹配项
            if (match.Success)
            {
                // 将匹配到的数字转换为整数并加14
                int incrementedNumber = int.Parse(match.Value) + 14;

                // 替换原始字符串中的数字部分为新数字
                return Regex.Replace(face, @"\d+", incrementedNumber.ToString());
            }

            // 如果没有找到匹配项，返回原始字符串
            return face;
        }

        static void CodeInsert()
        {
            // 文件路径
            string filePath = @"C:\Users\linsh\Desktop\Objects";
            string s = "";
            int mode = 2;
            int currentIndex = 0;
            int num = 0;

            try
            {
                // 打开文件并读取所有行
                string[] lines = File.ReadAllLines(filePath);
                switch (mode)
                {
                    case 0:
                        for (int i = 0; i < lines.Length; i++)
                        {
                            s =
                                "<s val="
                                + "\\"
                                + "\""
                                + "ys_yellow165"
                                + "\\"
                                + "\""
                                + ">单位生成："
                                + (i + 1).ToString()
                                + "/285</s>";
                            string newLine = lines[i] + "\n" + "gf_TipBarRefresh(\"" + @s + "\");";
                            Console.WriteLine(newLine);
                        }
                        break;
                    case 1:
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if ((i + 1) % 3 == 0)
                            {
                                // 在每行后面插入gf_TipBarRefresh
                                s =
                                    "<s val="
                                    + "\\"
                                    + "\""
                                    + "ys_yellow165"
                                    + "\\"
                                    + "\""
                                    + ">间隔插入："
                                    + (i + 1).ToString()
                                    + "/3385</s>";
                                string newLine =
                                    lines[i] + "\n" + "gf_TipBarRefresh(\"" + @s + "\");";

                                // 输出新行到控制台或文件
                                Console.WriteLine(newLine);
                            }
                            else
                            {
                                // 否则，直接输出原始行到控制台或文件
                                Console.WriteLine(lines[i]);
                            }
                        }
                        break;
                    case 2:
                        // 遍历每一行，直到到达最后一行的前一行
                        while (currentIndex < lines.Length - 1)
                        {
                            if (lines[currentIndex].Contains("MakeModelFaceAngle"))
                            {
                                //如果直接包含关键字则可以打印了，构建newLine并插入到当前行之后
                                s =
                                    "<s val="
                                    + "\\"
                                    + "\""
                                    + "ys_yellow165"
                                    + "\\"
                                    + "\""
                                    + ">装饰物："
                                    + (++num).ToString()
                                    + "/1153</s>";
                                string newLine =
                                    lines[currentIndex]
                                    + "\n"
                                    + "gf_TipBarRefresh(\""
                                    + @s
                                    + "\");";

                                // 输出新行到控制台或文件
                                Console.WriteLine(newLine);
                            }
                            else if (lines[currentIndex].Contains("gv_DoodedObjGroup"))
                            {
                                // 检查下一行是否包含关键字“MakeModelFaceAngle”
                                if (!lines[currentIndex + 1].Contains("MakeModelFaceAngle"))
                                {
                                    // 如果不包含关键字则可以打印了，构建newLine并插入到当前行之后
                                    s =
                                        "<s val="
                                        + "\\"
                                        + "\""
                                        + "ys_yellow165"
                                        + "\\"
                                        + "\""
                                        + ">装饰物："
                                        + (++num).ToString()
                                        + "/1153</s>";
                                    string newLine =
                                        lines[currentIndex]
                                        + "\n"
                                        + "gf_TipBarRefresh(\""
                                        + @s
                                        + "\");";

                                    // 输出新行到控制台或文件
                                    Console.WriteLine(newLine);
                                }
                                else
                                {
                                    //下一行包含关键字“MakeModelFaceAngle”，这里只要输出本行
                                    Console.WriteLine(lines[currentIndex]);
                                }
                            }
                            else
                            {
                                Console.WriteLine(lines[currentIndex]);
                            }

                            // 移动到下一行
                            currentIndex++;
                        }

                        // 处理最后一行
                        if (currentIndex == lines.Length - 1)
                        {
                            s =
                                "<s val="
                                + "\\"
                                + "\""
                                + "ys_yellow165"
                                + "\\"
                                + "\""
                                + ">装饰物："
                                + (++num).ToString()
                                + "/1153</s>";
                            string newLine =
                                lines[currentIndex] + "\n" + "gf_TipBarRefresh(\"" + @s + "\");";

                            // 输出新行到控制台或文件
                            Console.WriteLine(newLine);
                        }
                        break;
                }
            }
            catch (IOException ex)
            {
                // 处理文件读取过程中的异常
                Console.WriteLine("Error reading the file: " + ex.Message);
            }
        }

        static void TransXMLToNonFly()
        {
            // 定义文件路径（确保路径是正确的）
            // string filePath = @"T:\Work\SC2\重制版\虫出封锁线[Osia_重制版].SC2Map\Objects";
            string filePath = @"C:\Users\linsh\Desktop\Objects";
            try
            {
                // 加载XML文件
                XDocument doc = XDocument.Load(filePath);

                // 遍历所有的ObjectDoodad元素
                foreach (var obj in doc.Descendants("ObjectPoint"))
                {
                    // 提取必要的属性值
                    // int id = int.Parse(doodad.Attribute("Id").Value);
                    string position = obj.Attribute("Position").Value;
                    string type = obj.Attribute("Type").Value;

                    // 分割Position属性以获取X和Y坐标
                    string[] positionParts = position.Split(',');
                    string x = positionParts[0];
                    string y = positionParts[1];

                    // 输出新格式的字符串
                    if (type == "NoFlyZone")
                    {
                        Console.WriteLine($"PathAddNoFlyZone(Point({x}, {y}), 2.0, 2.0);");
                    }
                }
            }
            catch (IOException ex)
            {
                // 处理文件读取过程中的异常
                Console.WriteLine("Error reading the file: " + ex.Message);
            }
        }

        static void TransXMLToDoodad()
        {
            // 定义文件路径（确保路径是正确的）
            // string filePath = @"T:\Work\SC2\重制版\虫出封锁线[Osia_重制版].SC2Map\Objects";ActorCreate(null, "TechTreeDarkTemplar", null, null, null);
            string filePath = @"C:\Users\linsh\Desktop\Objects";
            try
            {
                // 加载XML文件
                XDocument doc = XDocument.Load(filePath);

                // 遍历所有的ObjectDoodad元素
                foreach (var obj in doc.Descendants("ObjectDoodad"))
                {
                    // 提取必要的属性值
                    string position = obj.Attribute("Position").Value;
                    string type = obj.Attribute("Type").Value;
                    string rotation = obj.Attribute("Rotation")?.Value;
                    double ro = 0.0;

                    // 分割Position属性以获取X和Y坐标
                    string[] positionParts = position.Split(',');
                    string x = positionParts[0];
                    string y = positionParts[1];

                    // 输出新格式的字符串
                    Console.WriteLine(
                        $"libNtve_gf_CreateActorAtPoint (\"{type}\", Point({x}, {y}));"
                    );
                    Console.WriteLine(
                        $"libBC0D3AAD_gf_HD_RegA_Simple(libNtve_gf_ActorLastCreated(), \"gv_DoodedObjGroup\");"
                    );
                    if (rotation != null)
                    {
                        double.TryParse(rotation, out ro);
                        //使用 Math.Round 进行四舍五入，然后转换为 int 类型来保留整数部分
                        rotation = ((int)Math.Round(RadianToDegree(ro)) - 90).ToString();
                        Console.WriteLine(
                            $"libNtve_gf_MakeModelFaceAngle(libNtve_gf_ActorLastCreated(), {rotation});"
                        );
                    }
                }
            }
            catch (IOException ex)
            {
                // 处理文件读取过程中的异常
                Console.WriteLine("Error reading the file: " + ex.Message);
            }
        }

        static void TransXMLToModel()
        {
            // 定义文件路径（确保路径是正确的）
            // string filePath = @"T:\Work\SC2\重制版\虫出封锁线[Osia_重制版].SC2Map\Objects";
            string filePath = @"C:\Users\linsh\Desktop\Objects";
            try
            {
                // 加载XML文件
                XDocument doc = XDocument.Load(filePath);

                // 遍历所有的ObjectDoodad元素
                foreach (var obj in doc.Descendants("ObjectDoodad"))
                {
                    // 提取必要的属性值
                    string position = obj.Attribute("Position").Value;
                    string type = obj.Attribute("Type").Value;
                    string rotation = obj.Attribute("Rotation")?.Value;
                    double ro = 0.0;

                    // 分割Position属性以获取X和Y坐标
                    string[] positionParts = position.Split(',');
                    string x = positionParts[0];
                    string y = positionParts[1];

                    // 输出新格式的字符串
                    Console.WriteLine(
                        $"libNtve_gf_CreateModelAtPoint(\"{type}\", Point({x}, {y}));"
                    );
                    Console.WriteLine(
                        $"libBC0D3AAD_gf_HD_RegA_Simple(libNtve_gf_ActorLastCreated(), \"gv_DoodedObjGroup\");"
                    );
                    if (rotation != null)
                    {
                        double.TryParse(rotation, out ro);
                        //使用 Math.Round 进行四舍五入，然后转换为 int 类型来保留整数部分
                        rotation = ((int)Math.Round(RadianToDegree(ro)) - 90).ToString();
                        Console.WriteLine(
                            $"libNtve_gf_MakeModelFaceAngle(libNtve_gf_ActorLastCreated(), {rotation});"
                        );
                    }
                }
            }
            catch (IOException ex)
            {
                // 处理文件读取过程中的异常
                Console.WriteLine("Error reading the file: " + ex.Message);
            }
        }

        static void TransXMLToUnit()
        {
            // 定义文件路径（确保路径是正确的）
            string filePath = "C:\\Users\\linsh\\Desktop\\Objects";
            try
            {
                // 加载XML文件
                XDocument doc = XDocument.Load(filePath);

                // 遍历所有的ObjectUnit元素
                foreach (var obj in doc.Descendants("ObjectUnit"))
                {
                    // 提取必要的属性值
                    // int id = int.Parse(obj.Attribute("Id").Value);
                    string position = obj.Attribute("Position").Value;
                    string type = obj.Attribute("UnitType").Value;
                    string rotation = obj.Attribute("Rotation")?.Value;
                    double ro = 0.0;
                    if (rotation != null)
                    {
                        double.TryParse(rotation, out ro);
                        //使用 Math.Round 进行四舍五入，然后转换为 int 类型来保留整数部分
                        rotation = ((int)Math.Round(RadianToDegree(ro)) - 90).ToString();
                    }
                    else
                    {
                        rotation = "270";
                    }

                    // 分割Position属性以获取X和Y坐标
                    string[] positionParts = position.Split(',');
                    string x = positionParts[0];
                    string y = positionParts[1];

                    // 替换Type属性中的"CCData_Blocker"为"CCData_UnitBlocker"
                    // string unitType = type.Replace("CCData_FKWall", "CCData_FK4Wall");

                    // 检查unitType是否包含"CCData_UnitBlocker"
                    // if (unitType.Contains("CCData_FK4Wall"))
                    // {
                    //     // 如果包含，则输出新格式的字符串
                    //     Console.WriteLine($"UnitCreate(1, \"{unitType}\", 0, gv_ID_ZL, Point({x}, {y}), rotation);");
                    // }

                    //输出新格式的字符串
                    Console.WriteLine(
                        $"UnitCreate(1, \"{type}\", 0, gv_ID_ZL, Point({x}, {y}), {rotation});"
                    );
                }
            }
            catch (IOException ex)
            {
                // 处理文件读取过程中的异常
                Console.WriteLine("Error reading the file: " + ex.Message);
            }
        }

        static string IntToString(int value)
        {
            string str = "";
            Stack<char> stack = new Stack<char>();
            bool isNagetive = false;
            int digit = 0;
            char c;

            //负整数
            if (value < 0)
            {
                isNagetive = true;
                while (value <= -10)
                {
                    digit = -(value % 10); //求个位数
                    c = (char)('0' + digit); //求digit对应的char
                    stack.Push(c); //压入栈
                    value = value / 10; //除以10的整数部分
                }
                if (value != 0) //最后一位
                {
                    c = (char)('0' + -value);
                    stack.Push(c);
                }
            }
            //0
            else if (value == 0)
            {
                c = (char)('0');
                str += c;
                return str;
            }
            //正整数
            else
            {
                while (value >= 10)
                {
                    digit = value % 10;
                    c = (char)('0' + digit);
                    stack.Push(c);
                    value = value / 10;
                }
                if (value != 0)
                {
                    c = (char)('0' + value);
                    stack.Push(c);
                }
            }

            if (isNagetive)
            {
                stack.Push('-');
            }

            while (stack.Count > 0)
            {
                str += stack.Pop();
            }

            return str;
        }

        public static double RadianToDegree(double radian)
        {
            return radian * (180.0 / Math.PI);
        }
    }
}
