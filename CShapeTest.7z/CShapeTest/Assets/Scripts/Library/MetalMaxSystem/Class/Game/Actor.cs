namespace MetalMaxSystem
{
    /// <summary>
    /// 演算体（媒体层脚本）
    /// </summary>
    public class Actor
    {

    }
}
